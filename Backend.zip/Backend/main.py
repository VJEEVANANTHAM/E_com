from fastapi import FastAPI,Request,WebSocket,WebSocketDisconnect
from fastapi.templating import Jinja2Templates
from database import engine, Base
from routes.auth import router as auth
from fastapi.middleware.cors import CORSMiddleware
from routes.products import router as products
from routes.session import router as session
# from routes.Login import router as Login_router
from routes.Profile import router as Profile_router
import os
from fastapi.responses import StreamingResponse,HTMLResponse
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from google import genai
from dotenv import load_dotenv
from fastapi.security import OAuth2AuthorizationCodeBearer,OAuth2PasswordRequestForm
from fastapi.templating import Jinja2Templates


app = FastAPI()
templates = Jinja2Templates(directory="templates")


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

Base.metadata.create_all(bind=engine)

app.include_router(
    auth,
    tags=["auth"]
)
app.include_router(
    session,
    tags=["session"]
)
app.include_router(
    products,
    prefix="/products",
    tags=["Products"]
)
app.include_router(
    Profile_router,
    tags=["Profile_router"]
)

load_dotenv() # Loads GEMINI_API_KEY from .env
client = genai.Client() # Uses environment variable by default

class PromptRequest(BaseModel):
    prompt: str

# templates=Jinja2Templates(directory="templates")

# @app.get("/",include_in_schema=False)
# def home(request:Request):
#     return templates.TemplateResponse(request,"home.hml")
# @app.post("/api/generate")
# async def generate_response(request: PromptRequest):
#     try:
#        
#         response = client.models.generate_content(
#             model="gemini-2.5-flash",
#             contents=request.prompt
#         )
        
#         return {"response": response.text}
#     except Exception as e:
#         raise HTTPException(status_code=500,detail=str(e))

@app.post("/api/generate")
async def generate_response(request: PromptRequest):
    try:
        def stream_generator():
            response = client.models.generate_content_stream(
                model="gemini-2.5-flash",
                contents=request.prompt
            )

            for chunk in response:
                if chunk.text:
                    print(chunk.text)
                    yield chunk.text
                    

        return StreamingResponse(
            stream_generator(),
            media_type="text/plain"
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    



@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        request,
        "index.html",
        {"name": "John"}
    )


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()

    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_text(data)
    except WebSocketDisconnect:
        print("Client disconnected")
