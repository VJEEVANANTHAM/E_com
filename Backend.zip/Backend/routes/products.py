from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from database import get_db
from models.Products import Product

router = APIRouter()


@router.get("/")
def get_products(
    db: Session = Depends(get_db)
):

    products = db.query(Product).all()

    return products
@router.get("/{id}")
def get_products(
    id:int,
    db: Session = Depends(get_db)
):  

    product = db.query(Product).filter_by(id=id).first()

    return product